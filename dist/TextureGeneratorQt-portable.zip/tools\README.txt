﻿Real-ESRGAN 超分放大（可选）放置目录。

把 realesrgan-ncnn-vulkan 解压到本目录，使其包含：
    tools\realesrgan-ncnn-vulkan\realesrgan-ncnn-vulkan.exe
    tools\realesrgan-ncnn-vulkan\models\...        (realesrgan-x4plus / x4plus-anime)

不放也能正常用软件，只是"无损放大"按钮会提示未找到 Real-ESRGAN。
下载：https://github.com/xinntao/Real-ESRGAN/releases
   (v0.2.5.0 的 realesrgan-ncnn-vulkan-20220424-windows.zip 即可)

Place the Real-ESRGAN upscaler here (optional). Without it the app works, but
the upscale button reports the binary is missing. See above for the exact layout.
