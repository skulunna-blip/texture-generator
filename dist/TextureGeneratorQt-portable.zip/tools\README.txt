﻿Real-ESRGAN 瓒呭垎鏀惧ぇ锛堝彲閫夛級鏀剧疆鐩綍銆?
鎶?realesrgan-ncnn-vulkan 瑙ｅ帇鍒版湰鐩綍锛屼娇鍏跺寘鍚細
    tools\realesrgan-ncnn-vulkan\realesrgan-ncnn-vulkan.exe
    tools\realesrgan-ncnn-vulkan\models\...        (realesrgan-x4plus / x4plus-anime)

涓嶆斁涔熻兘姝ｅ父鐢ㄨ蒋浠讹紝鍙槸"鏃犳崯鏀惧ぇ"鎸夐挳浼氭彁绀烘湭鎵惧埌 Real-ESRGAN銆?涓嬭浇锛歨ttps://github.com/xinntao/Real-ESRGAN/releases
   (v0.2.5.0 鐨?realesrgan-ncnn-vulkan-20220424-windows.zip 鍗冲彲)

Place the Real-ESRGAN upscaler here (optional). Without it the app works, but
the upscale button reports the binary is missing. See above for the exact layout.
